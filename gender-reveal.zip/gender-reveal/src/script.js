// Add baby images in a randomly scattered manner
const babyImageUrl = "https://img.freepik.com/premium-vector/baby-head-pixel-art-style_475147-2376.jpg?w=826";
for (let i = 0; i < 50; i++) {
    let babyImage = document.createElement("img");
    babyImage.src = babyImageUrl;
    babyImage.classList.add("baby-image");
    babyImage.style.top = `${Math.random() * 100}%`;
    babyImage.style.left = `${Math.random() * 100}%`;
    document.body.appendChild(babyImage);
}

function reveal() {
    document.body.style.backgroundColor = "skyblue";
    document.getElementById("message").classList.remove("hidden");
    document.getElementById("game-container").classList.add("hidden");
    document.getElementById("back-btn").classList.remove("hidden");

    for (let i = 0; i < 100; i++) {
        let confetti = document.createElement("div");
        confetti.classList.add("confetti");
        confetti.style.left = Math.random() * 100 + "vw";
        confetti.style.backgroundColor = ["red", "yellow", "blue", "green", "white"][Math.floor(Math.random() * 5)];
        confetti.style.animationDuration = Math.random() * 3 + 2 + "s";
        document.body.appendChild(confetti);
    }
}

function resetGame() {
    document.body.style.backgroundColor = "black";
    document.getElementById("message").classList.add("hidden");
    document.getElementById("game-container").classList.remove("hidden");
    document.getElementById("back-btn").classList.add("hidden");
    document.querySelectorAll(".confetti").forEach(el => el.remove());
}
